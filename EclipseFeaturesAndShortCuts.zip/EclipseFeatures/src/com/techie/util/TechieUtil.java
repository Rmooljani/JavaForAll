package com.techie.util;

public class TechieUtil {
	
	public static final String COMPANY_NAME="IBM INDIA";
	
	public static String getLocation() {
		return "Bangalore";
	}

}
