package com.glossary.api.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {
        "com.iris.glossary.api",
        "com.iris.glossary.controller",
        "com.iris.glossary.service"
    }
  /*  basePackageClasses = DemoBeanB1.class*/)
public class GlossaryApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(GlossaryApiApplication.class, args);
	}

}
