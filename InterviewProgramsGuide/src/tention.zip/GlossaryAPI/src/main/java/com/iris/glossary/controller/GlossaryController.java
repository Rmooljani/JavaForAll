package com.iris.glossary.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.google.gson.Gson;
import com.iris.glossary.service.GlossaryService;

@RestController
public class GlossaryController {
	
	@Autowired
	GlossaryService glossaryService;
	
	@GetMapping(value="/validate")
    public void validate(@RequestBody Map<String, Object> payload) throws Exception {
		System.out.println("Start");
		glossaryService.myService();
		System.out.println(glossaryService);
        Gson gson = new Gson();
        String json = gson.toJson(payload); 
        System.out.println(json);
    }

}
