package com.iris.glossary.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GlossaryApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(GlossaryApiApplication.class, args);
	}

}
